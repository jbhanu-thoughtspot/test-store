// <copyright file="TspublicRestV2DataLiveboardRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ThoughtSpotPublicRESTAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ThoughtSpotPublicRESTAPI.Standard;
    using ThoughtSpotPublicRESTAPI.Standard.Utilities;

    /// <summary>
    /// TspublicRestV2DataLiveboardRequest.
    /// </summary>
    public class TspublicRestV2DataLiveboardRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TspublicRestV2DataLiveboardRequest"/> class.
        /// </summary>
        public TspublicRestV2DataLiveboardRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="TspublicRestV2DataLiveboardRequest"/> class.
        /// </summary>
        /// <param name="offset">offset.</param>
        /// <param name="batchNumber">batchNumber.</param>
        /// <param name="batchSize">batchSize.</param>
        /// <param name="id">id.</param>
        /// <param name="transientContent">transientContent.</param>
        /// <param name="vizId">vizId.</param>
        /// <param name="runtimeFilter">runtimeFilter.</param>
        /// <param name="runtimeSort">runtimeSort.</param>
        /// <param name="formatType">formatType.</param>
        public TspublicRestV2DataLiveboardRequest(
            int? offset = 0,
            int? batchNumber = -1,
            int? batchSize = -1,
            string id = null,
            string transientContent = null,
            List<string> vizId = null,
            string runtimeFilter = null,
            string runtimeSort = null,
            Models.FormatTypeEnum? formatType = Models.FormatTypeEnum.COMPACT)
        {
            this.Offset = offset;
            this.BatchNumber = batchNumber;
            this.BatchSize = batchSize;
            this.Id = id;
            this.TransientContent = transientContent;
            this.VizId = vizId;
            this.RuntimeFilter = runtimeFilter;
            this.RuntimeSort = runtimeSort;
            this.FormatType = formatType;
        }

        /// <summary>
        /// The offset point, starting from where the records should be included in the response.
        /// If no input is provided then offset starts from 0.
        /// </summary>
        [JsonProperty("offset", NullValueHandling = NullValueHandling.Ignore)]
        public int? Offset { get; set; }

        /// <summary>
        /// An alternate way to set offset for the starting point of the response.
        /// The value in offset field will not be considered if batchNumber field has value greater than 0.
        /// Offset value will be calculated as (batchNumber - 1) * batchSize.
        /// It is mandatory to provide a value for batchSize with batchNumber.
        /// Example:
        /// Assume response has 100 records. Now,  batchNumber is set as 2 and batchSize as 10, then offset value will be 10. So, 10 records starting from 11th record will be considered.
        /// </summary>
        [JsonProperty("batchNumber", NullValueHandling = NullValueHandling.Ignore)]
        public int? BatchNumber { get; set; }

        /// <summary>
        /// The number of records that should be included in the response starting from offset position.
        /// If no input is provided, then all records starting from the value provided in offset is included in the response
        /// </summary>
        [JsonProperty("batchSize", NullValueHandling = NullValueHandling.Ignore)]
        public int? BatchSize { get; set; }

        /// <summary>
        /// The GUID of the Liveboard
        /// </summary>
        [JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
        public string Id { get; set; }

        /// <summary>
        /// If you have embedded ThoughtSpot in your host application, and you want to download Liveboard data with unsaved changes then, pass the transient content from the browser fetch request, using the getExportRequestForCurrentPinboard method. For more information, see https://developers.thoughtspot.com/docs/?pageid=liveboard-export-api#transient-pinboard . If value for this field is provided, then id will not be considered.
        /// </summary>
        [JsonProperty("transientContent", NullValueHandling = NullValueHandling.Ignore)]
        public string TransientContent { get; set; }

        /// <summary>
        /// A JSON array of GUIDs of the visualizations in the Liveboard.
        /// </summary>
        [JsonProperty("vizId", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> VizId { get; set; }

        /// <summary>
        /// JSON object which contains filter condition to filter the data at the time of data retrieval.
        /// Example: {"col1":"region","op1":"EQ","val1":"northeast","col2":"date","op2":"BET","val2":["1625126400000","1625126400000"]}
        /// For more information, see https://developers.thoughtspot.com/docs/?pageid=runtime-filters
        /// </summary>
        [JsonProperty("runtimeFilter", NullValueHandling = NullValueHandling.Ignore)]
        public string RuntimeFilter { get; set; }

        /// <summary>
        /// JSON object which provides columns to sort the data at the time of data retrieval.
        /// Example: {"sortCol1":"region","asc1":true,"sortCol2":"date"}
        /// For more information, see https://developers.thoughtspot.com/docs/?pageid=runtime-filters.
        /// </summary>
        [JsonProperty("runtimeSort", NullValueHandling = NullValueHandling.Ignore)]
        public string RuntimeSort { get; set; }

        /// <summary>
        /// The format of the data in the response.
        /// FULL: The response comes in "column":"value" format.
        /// COMPACT: The response includes only the value of the columns.
        /// </summary>
        [JsonProperty("formatType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.FormatTypeEnum? FormatType { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"TspublicRestV2DataLiveboardRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is TspublicRestV2DataLiveboardRequest other &&
                ((this.Offset == null && other.Offset == null) || (this.Offset?.Equals(other.Offset) == true)) &&
                ((this.BatchNumber == null && other.BatchNumber == null) || (this.BatchNumber?.Equals(other.BatchNumber) == true)) &&
                ((this.BatchSize == null && other.BatchSize == null) || (this.BatchSize?.Equals(other.BatchSize) == true)) &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.TransientContent == null && other.TransientContent == null) || (this.TransientContent?.Equals(other.TransientContent) == true)) &&
                ((this.VizId == null && other.VizId == null) || (this.VizId?.Equals(other.VizId) == true)) &&
                ((this.RuntimeFilter == null && other.RuntimeFilter == null) || (this.RuntimeFilter?.Equals(other.RuntimeFilter) == true)) &&
                ((this.RuntimeSort == null && other.RuntimeSort == null) || (this.RuntimeSort?.Equals(other.RuntimeSort) == true)) &&
                ((this.FormatType == null && other.FormatType == null) || (this.FormatType?.Equals(other.FormatType) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Offset = {(this.Offset == null ? "null" : this.Offset.ToString())}");
            toStringOutput.Add($"this.BatchNumber = {(this.BatchNumber == null ? "null" : this.BatchNumber.ToString())}");
            toStringOutput.Add($"this.BatchSize = {(this.BatchSize == null ? "null" : this.BatchSize.ToString())}");
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id == string.Empty ? "" : this.Id)}");
            toStringOutput.Add($"this.TransientContent = {(this.TransientContent == null ? "null" : this.TransientContent == string.Empty ? "" : this.TransientContent)}");
            toStringOutput.Add($"this.VizId = {(this.VizId == null ? "null" : $"[{string.Join(", ", this.VizId)} ]")}");
            toStringOutput.Add($"this.RuntimeFilter = {(this.RuntimeFilter == null ? "null" : this.RuntimeFilter == string.Empty ? "" : this.RuntimeFilter)}");
            toStringOutput.Add($"this.RuntimeSort = {(this.RuntimeSort == null ? "null" : this.RuntimeSort == string.Empty ? "" : this.RuntimeSort)}");
            toStringOutput.Add($"this.FormatType = {(this.FormatType == null ? "null" : this.FormatType.ToString())}");
        }
    }
}