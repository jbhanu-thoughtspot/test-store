// <copyright file="AdminControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ThoughtSpotPublicRESTAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using ThoughtSpotPublicRESTAPI.Standard;
    using ThoughtSpotPublicRESTAPI.Standard.Controllers;
    using ThoughtSpotPublicRESTAPI.Standard.Exceptions;
    using ThoughtSpotPublicRESTAPI.Standard.Http.Client;
    using ThoughtSpotPublicRESTAPI.Standard.Http.Response;
    using ThoughtSpotPublicRESTAPI.Standard.Utilities;
    using ThoughtSpotPublicRESTAPI.Tests.Helpers;

    /// <summary>
    /// AdminControllerTest.
    /// </summary>
    [TestFixture]
    public class AdminControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private AdminController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.AdminController;
        }

        /// <summary>
        /// To update the Thoughtspot cluster configuration, use this endpoint..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRestapiV2UpdateClusterConfig()
        {
            // Parameters for the API call
            Standard.Models.TspublicRestV2AdminConfigurationUpdateRequest body = null;

            // Perform API call
            bool result = false;
            try
            {
                result = await this.controller.RestapiV2UpdateClusterConfigAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// To reset the password of a ThoughtSpot user account, use this endpoint. 
        ///
        ///It is mandatory to use Authorization header with token of a user with admin access to successfully run this endpoint. 
        ///
        ///At least one of User Id or username is mandatory. When both are given, then user id will be considered..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRestapiV2ResetUserPassword()
        {
            // Parameters for the API call
            Standard.Models.TspublicRestV2AdminResetpasswordRequest body = null;

            // Perform API call
            bool result = false;
            try
            {
                result = await this.controller.RestapiV2ResetUserPasswordAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// To programmatically synchronize user accounts and user groups from external system with ThoughtSpot, use this endpoint. 
        ///
        /// The payload takes principals containing all users and groups present in the external system. 
        ///
        /// The users and user groups in Thoughtspot get updated for any matching inputs. 
        ///
        /// Any user and user group present in the input, but not present in the cluster, gets created in cluster. 
        ///n You can optionally choose to delete the user and groups from the cluster, that are not present in the input..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRestapiV2SyncPrincipal()
        {
            // Parameters for the API call
            Standard.Models.TspublicRestV2AdminSyncprincipalRequest body = null;

            // Perform API call
            Standard.Models.AdminsyncPrincipalResponse result = null;
            try
            {
                result = await this.controller.RestapiV2SyncPrincipalAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// To programmatically change the owner of one or several objects from one user account to another, use this endpoint. 
        ///
        ///You might want to transfer ownership of objects owned by a user to another active user, when the account is removed from the ThoughtSpot application..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRestapiV2ChangeAuthorOfObjects()
        {
            // Parameters for the API call
            Standard.Models.TspublicRestV2AdminChangeauthorRequest body = null;

            // Perform API call
            bool result = false;
            try
            {
                result = await this.controller.RestapiV2ChangeAuthorOfObjectsAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// To programmatically assign an author to one or several objects, use this endpoint. 
        ///
        ///Provide either user name or id as input. When both are given user id will be considered. 
        ///
        ///Requires administration privilege..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRestapiV2AssignAuthorToObjects()
        {
            // Parameters for the API call
            Standard.Models.TspublicRestV2AdminAssignauthorRequest body = null;

            // Perform API call
            bool result = false;
            try
            {
                result = await this.controller.RestapiV2AssignAuthorToObjectsAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// To logout one or more users from logged in session, use this endpoint. If no input is provided then all logged in users are force logged out. 
        ///
        ///Requires administration privilege.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRestapiV2ForceLogoutUsers()
        {
            // Parameters for the API call
            Standard.Models.TspublicRestV2AdminForcelogoutRequest body = null;

            // Perform API call
            bool result = false;
            try
            {
                result = await this.controller.RestapiV2ForceLogoutUsersAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }
    }
}