// <copyright file="SessionControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ThoughtSpotPublicRESTAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using ThoughtSpotPublicRESTAPI.Standard;
    using ThoughtSpotPublicRESTAPI.Standard.Controllers;
    using ThoughtSpotPublicRESTAPI.Standard.Exceptions;
    using ThoughtSpotPublicRESTAPI.Standard.Http.Client;
    using ThoughtSpotPublicRESTAPI.Standard.Http.Response;
    using ThoughtSpotPublicRESTAPI.Standard.Utilities;
    using ThoughtSpotPublicRESTAPI.Tests.Helpers;

    /// <summary>
    /// SessionControllerTest.
    /// </summary>
    [TestFixture]
    public class SessionControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private SessionController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.SessionController;
        }

        /// <summary>
        /// Get Session object information.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRestapiV2GetSessionInfo()
        {
            // Perform API call
            object result = null;
            try
            {
                result = await this.controller.RestapiV2GetSessionInfoAsync();
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// You can programmatically create login session for a user in ThoughtSpot using this endpoint. 
        ///
        ///You can create session by either providing userName and password as inputs in this request body or by including "Authorization" header with the token generated through the endpoint /tspublic/rest/v2/session/gettoken. 
        ///
        ///userName and password input is given precedence over "Authorization" header, when both are included in the request..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRestapiV2Login()
        {
            // Parameters for the API call
            Standard.Models.TspublicRestV2SessionLoginRequest body = null;

            // Perform API call
            Standard.Models.SessionLoginResponse result = null;
            try
            {
                result = await this.controller.RestapiV2LoginAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        ///  To programmatically create session token for a user in ThoughtSpot, use this endpoint. 
        ///
        ///You can generate the token for a user by providing password or secret key from the cluster. 
        ///
        ///You need to enable trusted authentication to generate secret key. To generate secret key, follow below steps. 
        ///
        ///
        /// 1. Click the Develop tab. 
        ///
        ///
        /// 2. Under Customizations, click Settings. 
        ///
        ///
        /// 3. To enable trusted authentication, turn on the toggle. 
        ///
        ///
        /// 4. A secret_key for trusted authentication is generated. 
        ///
        ///
        /// 5. Click the clipboard icon to copy the token. 
        ///
        ///
        /// 
        ///
        ///Password is given precedence over secretKey input, when both are included in the request..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRestapiV2GetToken()
        {
            // Parameters for the API call
            Standard.Models.TspublicRestV2SessionGettokenRequest body = null;

            // Perform API call
            Standard.Models.SessionLoginResponse result = null;
            try
            {
                result = await this.controller.RestapiV2GetTokenAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// To log a user out of the current session, use this endpoint.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRestapiV2Logout()
        {
            // Parameters for the API call
            object body = null;

            // Perform API call
            bool result = false;
            try
            {
                result = await this.controller.RestapiV2LogoutAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// To expire or revoke a token for a user, use this endpoint.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRestapiV2RevokeToken()
        {
            // Parameters for the API call
            object body = null;

            // Perform API call
            bool result = false;
            try
            {
                result = await this.controller.RestapiV2RevokeTokenAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }
    }
}