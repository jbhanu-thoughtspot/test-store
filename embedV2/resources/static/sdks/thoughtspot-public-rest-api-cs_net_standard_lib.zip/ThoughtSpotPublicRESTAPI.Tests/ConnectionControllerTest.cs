// <copyright file="ConnectionControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ThoughtSpotPublicRESTAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using ThoughtSpotPublicRESTAPI.Standard;
    using ThoughtSpotPublicRESTAPI.Standard.Controllers;
    using ThoughtSpotPublicRESTAPI.Standard.Exceptions;
    using ThoughtSpotPublicRESTAPI.Standard.Http.Client;
    using ThoughtSpotPublicRESTAPI.Standard.Http.Response;
    using ThoughtSpotPublicRESTAPI.Standard.Utilities;
    using ThoughtSpotPublicRESTAPI.Tests.Helpers;

    /// <summary>
    /// ConnectionControllerTest.
    /// </summary>
    [TestFixture]
    public class ConnectionControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private ConnectionController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.ConnectionController;
        }

        /// <summary>
        /// To programmatically create a connection in the ThoughtSpot system use this API endpoint.
        ///Using this API, you can create a connection and assign groups.
        ///To create a connection, you require admin connection privileges.
        ///All connections created in the ThoughtSpot system are added to ALL_GROUP.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRestapiV2CreateConnection()
        {
            // Parameters for the API call
            Standard.Models.TspublicRestV2ConnectionCreateRequest body = null;

            // Perform API call
            Standard.Models.CreateConnectionResponse result = null;
            try
            {
                result = await this.controller.RestapiV2CreateConnectionAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// You can use this endpoint to programmatically modify an existing connection
        ///To modify a connection, you require admin connection privileges.
        ///At least one of Connection Id or connectionname is mandatory. When both are given, then connection id will be considered and connectionname will be updated.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRestapiV2UpdateConnection()
        {
            // Parameters for the API call
            Standard.Models.TspublicRestV2ConnectionUpdateRequest body = null;

            // Perform API call
            bool result = false;
            try
            {
                result = await this.controller.RestapiV2UpdateConnectionAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// To programmatically add table to an existing connection use this endpoint.
        ///When you assign groups to a connection, the connection inherits the privileges assigned to those groups.
        ///At least one of Connection Id or connectionname is mandatory. When both are given, then connection id will be considered..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRestapiV2AddTableToConnection()
        {
            // Parameters for the API call
            Standard.Models.TspublicRestV2ConnectionAddtableRequest body = null;

            // Perform API call
            bool result = false;
            try
            {
                result = await this.controller.RestapiV2AddTableToConnectionAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// To programmatically remove a table from a connection use API endpoint.
        ///The API removes only the connection association. It does not delete the connection or group from the Thoughtspot system.
        /// At least one of id or name of connection is required. When both are given connection id will be considered..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRestapiV2RemoveTableFromConnection()
        {
            // Parameters for the API call
            Standard.Models.TspublicRestV2ConnectionRemovetableRequest body = null;

            // Perform API call
            bool result = false;
            try
            {
                result = await this.controller.RestapiV2RemoveTableFromConnectionAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// To get the details of a specific connection or all connections in the ThoughtSpot system use this end point..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRestapiV2SearchConnection()
        {
            // Parameters for the API call
            Standard.Models.TspublicRestV2ConnectionSearchRequest body = null;

            // Perform API call
            List<Standard.Models.ConnectionResponse> result = null;
            try
            {
                result = await this.controller.RestapiV2SearchConnectionAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// To get the details of tables from a connection, use this endpoint. 
        ///
        ///You can get the details of tables in the data platform for the connection id provided..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRestapiV2GetConnectionTables()
        {
            // Parameters for the API call
            Standard.Models.TspublicRestV2ConnectionTableRequest body = null;

            // Perform API call
            Standard.Models.ConnectionTableResponse result = null;
            try
            {
                result = await this.controller.RestapiV2GetConnectionTablesAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// To get the details of columns in a table associated to a connection, use this endpoint. 
        ///
        ///You can get the columns of any table available in the data platform for the connection id provided..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRestapiV2GetConnectionTableColumns()
        {
            // Parameters for the API call
            Standard.Models.TspublicRestV2ConnectionTablecoloumnRequest body = null;

            // Perform API call
            Standard.Models.ConnectionTableColumnsResponse result = null;
            try
            {
                result = await this.controller.RestapiV2GetConnectionTableColumnsAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }
    }
}