
# Sort Order 1 Enum

Order in which sortBy should be applied. Valid values

## Enumeration

`SortOrder1Enum`

## Fields

| Name |
|  --- |
| `DEFAULT` |
| `ASC` |
| `DESC` |

