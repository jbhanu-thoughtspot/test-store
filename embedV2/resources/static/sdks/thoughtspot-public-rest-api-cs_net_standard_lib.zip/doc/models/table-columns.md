
# Table Columns

## Structure

`TableColumns`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | Name of the column |
| `DataType` | `string` | Optional | Datatype of the column |

## Example (as JSON)

```json
{
  "name": null,
  "dataType": null
}
```

