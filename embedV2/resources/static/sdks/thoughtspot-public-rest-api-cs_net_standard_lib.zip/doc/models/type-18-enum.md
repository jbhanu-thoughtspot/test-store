
# Type 18 Enum

Type of metadata object. Valid values: Liveboard|Answer|DataObject|Column

## Enumeration

`Type18Enum`

## Fields

| Name |
|  --- |
| `LIVEBOARD` |
| `ANSWER` |
| `DATAOBJECT` |
| `COLUMN` |

