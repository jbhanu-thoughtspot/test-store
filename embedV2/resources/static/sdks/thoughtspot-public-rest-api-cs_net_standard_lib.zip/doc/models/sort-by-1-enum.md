
# Sort by 1 Enum

Field based on which the re.sponse needs to be ordered. Valid values

## Enumeration

`SortBy1Enum`

## Fields

| Name |
|  --- |
| `DEFAULT` |
| `NAME` |
| `DISPLAYNAME` |
| `AUTHOR` |
| `CREATED` |
| `MODIFIED` |
| `LASTACCESSED` |
| `SYNCED` |
| `VIEWS` |
| `NONE` |
| `USERSTATE` |
| `ROWCOUNT` |

