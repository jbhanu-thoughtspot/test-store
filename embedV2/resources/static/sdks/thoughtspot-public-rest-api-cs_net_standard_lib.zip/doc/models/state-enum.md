
# State Enum

Status of user account. acitve or inactive.

## Enumeration

`StateEnum`

## Fields

| Name |
|  --- |
| `ACTIVE` |
| `INACTIVE` |
| `EXPIRED` |
| `LOCKED` |
| `PENDING` |

