
# Type 1 Enum

Type of access detail provided

## Enumeration

`Type1Enum`

## Fields

| Name |
|  --- |
| `USER` |
| `USERGROUP` |

