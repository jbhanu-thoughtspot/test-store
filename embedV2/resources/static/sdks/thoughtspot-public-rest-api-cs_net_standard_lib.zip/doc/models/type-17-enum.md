
# Type 17 Enum

Type of file to be generated. Valid values: CSV/XLSX/PDF/PNG.

## Enumeration

`Type17Enum`

## Fields

| Name |
|  --- |
| `CSV` |
| `XLSX` |
| `PDF` |
| `PNG` |

