
# Tag Name and Id Input

## Structure

`TagNameAndIdInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | Name of the tags |
| `Id` | `string` | Optional | GUID of the tags |

## Example (as JSON)

```json
{
  "name": null,
  "id": null
}
```

