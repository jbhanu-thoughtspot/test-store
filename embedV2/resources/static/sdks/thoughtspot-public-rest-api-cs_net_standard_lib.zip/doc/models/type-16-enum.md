
# Type 16 Enum

Type of file to be generated.

## Enumeration

`Type16Enum`

## Fields

| Name |
|  --- |
| `CSV` |
| `XLSX` |
| `PDF` |
| `PNG` |

