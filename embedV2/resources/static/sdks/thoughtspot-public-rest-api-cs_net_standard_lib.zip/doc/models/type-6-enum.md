
# Type 6 Enum

Type of the metadata object being searched.

## Enumeration

`Type6Enum`

## Fields

| Name |
|  --- |
| `ANSWER` |
| `LIVEBOARD` |
| `DATAOBJECT` |
| `COLUMN` |
| `JOIN` |
| `CONNECTION` |
| `TAG` |
| `USER` |
| `USERGROUP` |

