
# Group Name and ID Input

## Structure

`GroupNameAndIDInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | Name of the group |
| `Id` | `string` | Optional | GUID of the group |

## Example (as JSON)

```json
{
  "name": null,
  "id": null
}
```

