
# Name and Id Input

## Structure

`NameAndIdInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | Name of the user |
| `Id` | `string` | Optional | GUID of the user |

## Example (as JSON)

```json
{
  "name": null,
  "id": null
}
```

