
# Type 10 Enum

Type of user group. LOCAL_GROUP indicates that the user is created locally in the ThoughtSpot system.

## Enumeration

`Type10Enum`

## Fields

| Name |
|  --- |
| `LOCALGROUP` |
| `TENANTGROUP` |

