
# Type 2 Enum

Type of the metadata objec

## Enumeration

`Type2Enum`

## Fields

| Name |
|  --- |
| `LIVEBOARD` |
| `ANSWER` |
| `DATAOBJECT` |
| `COLUMN` |

