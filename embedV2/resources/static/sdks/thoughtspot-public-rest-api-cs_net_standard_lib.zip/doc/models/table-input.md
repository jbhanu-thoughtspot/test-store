
# Table Input

## Structure

`TableInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | Name of the table |
| `Id` | `string` | Optional | GUID of the Table |

## Example (as JSON)

```json
{
  "name": null,
  "id": null
}
```

