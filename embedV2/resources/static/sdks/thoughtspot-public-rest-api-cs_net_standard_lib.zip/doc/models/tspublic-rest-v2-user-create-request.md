
# Tspublic Rest V2 User Create Request

## Structure

`TspublicRestV2UserCreateRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | Name of the user. The username string must be unique. |
| `DisplayName` | `string` | Required | A unique display name string for the user account, usually their first and last name |
| `Visibility` | [`Models.VisibilityEnum?`](../../doc/models/visibility-enum.md) | Optional | Visibility of the user. The visibility attribute is set to DEFAULT when creating a user. The DEFAULT attribute makes a user visible to other users and user groups, and this allows them to share objects<br>**Default**: `VisibilityEnum.DEFAULT` |
| `Mail` | `string` | Optional | Email of the user account |
| `Password` | `string` | Required | Password for the user account. |
| `OrgIds` | `List<int>` | Optional | Array of org identifiers. If no value is provided then user will be created in the organization associated with the login session. |
| `Groups` | [`List<Models.GroupNameAndIDInput>`](../../doc/models/group-name-and-id-input.md) | Optional | Array of objects of groups that the user belong to. |
| `State` | [`Models.StateEnum?`](../../doc/models/state-enum.md) | Optional | Status of user account. acitve or inactive.<br>**Default**: `StateEnum.ACTIVE` |
| `NotifyOnShare` | `bool?` | Optional | User preference for receiving email notifications when another ThoughtSpot user shares answers or pinboards.<br>**Default**: `true` |
| `ShowWalkMe` | `bool?` | Optional | The user preference for revisiting the onboarding experience.<br>**Default**: `true` |
| `AnalystOnboardingComplete` | `bool?` | Optional | ThoughtSpot provides an interactive guided walkthrough to onboard new users. The onboarding experience leads users through a set of actions to help users get started and accomplish their tasks quickly. The users can turn off the Onboarding experience and access it again when they need assistance with the ThoughtSpot UI.<br>**Default**: `false` |
| `Type` | [`Models.Type8Enum?`](../../doc/models/type-8-enum.md) | Optional | Type of user. LOCAL_USER indicates that the user is created locally in the ThoughtSpot system.<br>**Default**: `Type8Enum.LOCAL_USER` |

## Example (as JSON)

```json
{
  "name": "name0",
  "displayName": "displayName2",
  "visibility": null,
  "mail": null,
  "password": "password4",
  "orgIds": null,
  "groups": null,
  "state": null,
  "notifyOnShare": null,
  "showWalkMe": null,
  "analystOnboardingComplete": null,
  "type": null
}
```

