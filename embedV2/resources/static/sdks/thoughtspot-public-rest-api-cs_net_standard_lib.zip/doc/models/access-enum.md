
# Access Enum

Minimum access level that the specified user or user group has. If no input is provided then minimum access of READ_ONLY will be considered.

## Enumeration

`AccessEnum`

## Fields

| Name |
|  --- |
| `READONLY` |
| `MODIFY` |

