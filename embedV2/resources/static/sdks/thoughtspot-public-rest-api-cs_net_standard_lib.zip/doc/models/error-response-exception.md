
# Error Response Exception

## Structure

`ErrorResponseException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Error` | `object` | Optional | - |

## Example (as JSON)

```json
{
  "error": null
}
```

