# Report

```csharp
ReportController reportController = client.ReportController;
```

## Class Name

`ReportController`

## Methods

* [Restapi V2 Answer Report](../../doc/controllers/report.md#restapi-v2-answer-report)
* [Restapi V2 Liveboard Report](../../doc/controllers/report.md#restapi-v2-liveboard-report)


# Restapi V2 Answer Report

To programmatically download Answer data as a file, use this endpoint.

The PDF will download data in the tabular format even if Answer is saved as chart.

```csharp
RestapiV2AnswerReportAsync(
    Models.TspublicRestV2ReportAnswerRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.TspublicRestV2ReportAnswerRequest`](../../doc/models/tspublic-rest-v2-report-answer-request.md) | Body, Optional | - |

## Response Type

`Task<object>`

## Example Usage

```csharp
try
{
    object result = await reportController.RestapiV2AnswerReportAsync(null);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Operation failed | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Restapi V2 Liveboard Report

To programmatically download Liveboard data or specific Visualization data from Liveboard as a file, use this endpoint

```csharp
RestapiV2LiveboardReportAsync(
    Models.TspublicRestV2ReportLiveboardRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.TspublicRestV2ReportLiveboardRequest`](../../doc/models/tspublic-rest-v2-report-liveboard-request.md) | Body, Optional | - |

## Response Type

`Task<object>`

## Example Usage

```csharp
try
{
    object result = await reportController.RestapiV2LiveboardReportAsync(null);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Operation failed | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

