# Materialization

```csharp
MaterializationController materializationController = client.MaterializationController;
```

## Class Name

`MaterializationController`


# Restapi V2 Refresh Materialized View

Use this endpoint to refresh data in the materialized view by running the query associated with it

```csharp
RestapiV2RefreshMaterializedViewAsync(
    Models.TspublicRestV2MaterializationRefreshviewRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.TspublicRestV2MaterializationRefreshviewRequest`](../../doc/models/tspublic-rest-v2-materialization-refreshview-request.md) | Body, Optional | - |

## Response Type

`Task<object>`

## Example Usage

```csharp
try
{
    object result = await materializationController.RestapiV2RefreshMaterializedViewAsync(null);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Operation failed | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

