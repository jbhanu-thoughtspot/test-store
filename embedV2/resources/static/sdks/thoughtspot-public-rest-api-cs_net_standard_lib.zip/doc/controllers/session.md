# Session

```csharp
SessionController sessionController = client.SessionController;
```

## Class Name

`SessionController`

## Methods

* [Restapi V2 Get Session Info](../../doc/controllers/session.md#restapi-v2-get-session-info)
* [Restapi V2 Login](../../doc/controllers/session.md#restapi-v2-login)
* [Restapi V2 Get Token](../../doc/controllers/session.md#restapi-v2-get-token)
* [Restapi V2 Logout](../../doc/controllers/session.md#restapi-v2-logout)
* [Restapi V2 Revoke Token](../../doc/controllers/session.md#restapi-v2-revoke-token)


# Restapi V2 Get Session Info

Get Session object information

```csharp
RestapiV2GetSessionInfoAsync()
```

## Response Type

`Task<object>`

## Example Usage

```csharp
try
{
    object result = await sessionController.RestapiV2GetSessionInfoAsync();
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Operation failed | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Restapi V2 Login

You can programmatically create login session for a user in ThoughtSpot using this endpoint.

You can create session by either providing userName and password as inputs in this request body or by including "Authorization" header with the token generated through the endpoint /tspublic/rest/v2/session/gettoken.

userName and password input is given precedence over "Authorization" header, when both are included in the request.

```csharp
RestapiV2LoginAsync(
    Models.TspublicRestV2SessionLoginRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.TspublicRestV2SessionLoginRequest`](../../doc/models/tspublic-rest-v2-session-login-request.md) | Body, Optional | - |

## Response Type

[`Task<Models.SessionLoginResponse>`](../../doc/models/session-login-response.md)

## Example Usage

```csharp
try
{
    SessionLoginResponse result = await sessionController.RestapiV2LoginAsync(null);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Operation failed | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Restapi V2 Get Token

To programmatically create session token for a user in ThoughtSpot, use this endpoint.

You can generate the token for a user by providing password or secret key from the cluster.

You need to enable trusted authentication to generate secret key. To generate secret key, follow below steps.

1. Click the Develop tab.

2. Under Customizations, click Settings.

3. To enable trusted authentication, turn on the toggle.

4. A secret_key for trusted authentication is generated.

5. Click the clipboard icon to copy the token.

Password is given precedence over secretKey input, when both are included in the request.

```csharp
RestapiV2GetTokenAsync(
    Models.TspublicRestV2SessionGettokenRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.TspublicRestV2SessionGettokenRequest`](../../doc/models/tspublic-rest-v2-session-gettoken-request.md) | Body, Optional | - |

## Response Type

[`Task<Models.SessionLoginResponse>`](../../doc/models/session-login-response.md)

## Example Usage

```csharp
try
{
    SessionLoginResponse result = await sessionController.RestapiV2GetTokenAsync(null);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Operation failed | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Restapi V2 Logout

To log a user out of the current session, use this endpoint

```csharp
RestapiV2LogoutAsync(
    object body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | `object` | Body, Optional | - |

## Response Type

`Task<bool>`

## Example Usage

```csharp
try
{
    bool? result = await sessionController.RestapiV2LogoutAsync(null);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Operation failed | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Restapi V2 Revoke Token

To expire or revoke a token for a user, use this endpoint

```csharp
RestapiV2RevokeTokenAsync(
    object body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | `object` | Body, Optional | - |

## Response Type

`Task<bool>`

## Example Usage

```csharp
try
{
    bool? result = await sessionController.RestapiV2RevokeTokenAsync(null);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Operation failed | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

