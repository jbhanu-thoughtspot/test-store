# Materialization

```ts
const materializationController = new MaterializationController(client);
```

## Class Name

`MaterializationController`


# Restapi V2 Refresh Materialized View

Use this endpoint to refresh data in the materialized view by running the query associated with it

```ts
async restapiV2RefreshMaterializedView(
  body?: TspublicRestV2MaterializationRefreshviewRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<unknown>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`TspublicRestV2MaterializationRefreshviewRequest \| undefined`](../../doc/models/tspublic-rest-v2-materialization-refreshview-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`unknown`

## Example Usage

```ts
const contentType = null;
try {
  const { result, ...httpResponse } = await materializationController.restapiV2RefreshMaterializedView();
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Operation failed | [`ErrorResponseError`](../../doc/models/error-response-error.md) |

