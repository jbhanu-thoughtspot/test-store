
# Type 15 Enum

Type of the connect being searched. Valid values: SNOWFLAKE|AMAZON_REDSHIFT|GOOGLE_BIGQUERY|AZURE_SYNAPSE|TERADATA|STARBURST|SAP_HANA|ORACLE_ADW|DATABRICKS|DENODO

## Enumeration

`Type15Enum`

## Fields

| Name |
|  --- |
| `sNOWFLAKE` |
| `aMAZONREDSHIFT` |
| `gOOGLEBIGQUERY` |
| `aZURESYNAPSE` |
| `tERADATA` |
| `sTARBURST` |
| `sAPHANA` |
| `oRACLEADW` |
| `dATABRICKS` |
| `dENODO` |
| `dREMIO` |

