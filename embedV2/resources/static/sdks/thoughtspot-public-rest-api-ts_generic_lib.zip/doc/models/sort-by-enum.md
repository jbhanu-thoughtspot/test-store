
# Sort by Enum

Field based on which the response needs to be ordered.

## Enumeration

`SortByEnum`

## Fields

| Name |
|  --- |
| `dEFAULT` |
| `nAME` |
| `dISPLAYNAME` |
| `aUTHOR` |
| `cREATED` |
| `mODIFIED` |
| `lASTACCESSED` |
| `sYNCED` |
| `vIEWS` |
| `nONE` |
| `uSERSTATE` |
| `rOWCOUNT` |

