
# Type 13 Enum

Type of the data object

## Enumeration

`Type13Enum`

## Fields

| Name |
|  --- |
| `lIVEBOARD` |
| `dATAOBJECT` |
| `cOLUMN` |
| `jOIN` |

