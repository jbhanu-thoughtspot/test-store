
# Group Name and ID

## Structure

`GroupNameAndID`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Optional | Name of the group |
| `id` | `string \| undefined` | Optional | GUID of the group |

## Example (as JSON)

```json
{
  "name": null,
  "id": null
}
```

