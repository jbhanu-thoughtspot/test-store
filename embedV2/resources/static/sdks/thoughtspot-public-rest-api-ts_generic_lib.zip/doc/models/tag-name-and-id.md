
# Tag Name and ID

## Structure

`TagNameAndID`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Optional | Name of the group to which group  is added |
| `id` | `string \| undefined` | Optional | GUID of the group to which group  is added |

## Example (as JSON)

```json
{
  "name": null,
  "id": null
}
```

