
# Visibility 2 Enum

Visibility of the user group. The visibility attribute is set to DEFAULT. The DEFAULT attribute makes the user group visible for other user groups and allows them to share objects.

## Enumeration

`Visibility2Enum`

## Fields

| Name |
|  --- |
| `dEFAULT` |
| `nONSHARABLE` |
| `sHARABLE` |

