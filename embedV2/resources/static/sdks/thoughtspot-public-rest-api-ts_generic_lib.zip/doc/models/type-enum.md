
# Type Enum

Type of the metadata object

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `aNSWER` |
| `lIVEBOARD` |
| `dATAOBJECT` |
| `cONNECTION` |

