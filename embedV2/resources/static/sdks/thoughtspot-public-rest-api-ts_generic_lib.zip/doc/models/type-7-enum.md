
# Type 7 Enum

## Enumeration

`Type7Enum`

## Fields

| Name |
|  --- |
| `lIVEBOARD` |
| `aNSWER` |
| `dATAOBJECT` |
| `cOLUMN` |

