
# Type 4 Enum

## Enumeration

`Type4Enum`

## Fields

| Name |
|  --- |
| `aNSWER` |
| `lIVEBOARD` |
| `dATAOBJECT` |
| `cOLUMN` |
| `jOIN` |
| `cONNECTION` |
| `tAG` |
| `uSER` |
| `uSERGROUP` |

