
# Table Input

## Structure

`TableInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Optional | Name of the table |
| `id` | `string \| undefined` | Optional | GUID of the Table |

## Example (as JSON)

```json
{
  "name": null,
  "id": null
}
```

