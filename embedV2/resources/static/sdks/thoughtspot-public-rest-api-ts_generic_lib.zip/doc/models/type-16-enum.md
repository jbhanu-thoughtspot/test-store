
# Type 16 Enum

Type of file to be generated.

## Enumeration

`Type16Enum`

## Fields

| Name |
|  --- |
| `cSV` |
| `xLSX` |
| `pDF` |
| `pNG` |

