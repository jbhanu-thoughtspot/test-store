
# Create Table Response

## Structure

`CreateTableResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `logicalTableHeader` | [`LogicalTableHeader \| undefined`](../../doc/models/logical-table-header.md) | Optional | - |
| `physicalTableId` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "logicalTableHeader": null,
  "physicalTableId": null
}
```

