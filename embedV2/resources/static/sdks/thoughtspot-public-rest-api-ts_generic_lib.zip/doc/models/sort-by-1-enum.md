
# Sort by 1 Enum

Field based on which the re.sponse needs to be ordered. Valid values

## Enumeration

`SortBy1Enum`

## Fields

| Name |
|  --- |
| `dEFAULT` |
| `nAME` |
| `dISPLAYNAME` |
| `aUTHOR` |
| `cREATED` |
| `mODIFIED` |
| `lASTACCESSED` |
| `sYNCED` |
| `vIEWS` |
| `nONE` |
| `uSERSTATE` |
| `rOWCOUNT` |

