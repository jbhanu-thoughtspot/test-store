
# State Enum

Status of user account. acitve or inactive.

## Enumeration

`StateEnum`

## Fields

| Name |
|  --- |
| `aCTIVE` |
| `iNACTIVE` |
| `eXPIRED` |
| `lOCKED` |
| `pENDING` |

