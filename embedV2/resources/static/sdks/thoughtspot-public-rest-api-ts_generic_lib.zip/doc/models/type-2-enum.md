
# Type 2 Enum

Type of the metadata objec

## Enumeration

`Type2Enum`

## Fields

| Name |
|  --- |
| `lIVEBOARD` |
| `aNSWER` |
| `dATAOBJECT` |
| `cOLUMN` |

