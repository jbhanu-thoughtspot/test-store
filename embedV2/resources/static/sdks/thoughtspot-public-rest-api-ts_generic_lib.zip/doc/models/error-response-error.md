
# Error Response Error

## Structure

`ErrorResponseError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | `unknown \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "error": null
}
```

