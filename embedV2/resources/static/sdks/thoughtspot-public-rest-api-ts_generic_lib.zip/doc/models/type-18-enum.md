
# Type 18 Enum

Type of metadata object. Valid values: Liveboard|Answer|DataObject|Column

## Enumeration

`Type18Enum`

## Fields

| Name |
|  --- |
| `lIVEBOARD` |
| `aNSWER` |
| `dATAOBJECT` |
| `cOLUMN` |

