
# Format Type 3 Enum

The format in which to export the objects

## Enumeration

`FormatType3Enum`

## Fields

| Name |
|  --- |
| `yAML` |
| `jSON` |

