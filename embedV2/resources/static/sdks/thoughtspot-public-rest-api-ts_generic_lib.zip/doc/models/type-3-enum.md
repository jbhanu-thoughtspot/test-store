
# Type 3 Enum

Type of the metadata object being searched.

## Enumeration

`Type3Enum`

## Fields

| Name |
|  --- |
| `aNSWER` |
| `lIVEBOARD` |
| `dATAOBJECTALL` |
| `dATAOBJECTWORKSHEET` |
| `dATAOBJECTTABLE` |
| `dATAOBJECTUSERDEFINED` |
| `dATAOBJECTVIEW` |
| `dATAOBJECTCALENDARTABLE` |
| `cOLUMNALL` |
| `cOLUMNWORKSHEET` |
| `cOLUMNTABLE` |
| `cOLUMNUSERDEFINED` |
| `cOLUMNVIEW` |
| `cOLUMNCALENDARTABLE` |
| `jOIN` |
| `cONNECTION` |
| `tAG` |
| `uSER` |
| `uSERGROUP` |

