
# Tspublic Rest V2 Metadata Homeliveboard Unassign Request

## Structure

`TspublicRestV2MetadataHomeliveboardUnassignRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userName` | `string \| undefined` | Optional | Name of the user |
| `userId` | `string \| undefined` | Optional | The GUID of the user |

## Example (as JSON)

```json
{
  "userName": null,
  "userId": null
}
```

