
# Tspublic Rest V2 Report Answer Request

## Structure

`TspublicRestV2ReportAnswerRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Required | GUID of the Answer to download. |
| `type` | [`Type16Enum`](../../doc/models/type-16-enum.md) | Required | Type of file to be generated. |

## Example (as JSON)

```json
{
  "id": "id0",
  "type": "PDF"
}
```

