
# Sort Order Enum

Order in which sortBy should be applied.

## Enumeration

`SortOrderEnum`

## Fields

| Name |
|  --- |
| `dEFAULT` |
| `aSC` |
| `dESC` |

