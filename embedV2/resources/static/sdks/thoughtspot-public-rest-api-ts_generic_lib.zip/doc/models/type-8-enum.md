
# Type 8 Enum

Type of user. LOCAL_USER indicates that the user is created locally in the ThoughtSpot system.

## Enumeration

`Type8Enum`

## Fields

| Name |
|  --- |
| `uNKNOWN` |
| `lDAPUSER` |
| `sAMLUSER` |
| `oIDCUSER` |
| `lOCALUSER` |

