
# Type 14 Enum

Type of the data connection.

## Enumeration

`Type14Enum`

## Fields

| Name |
|  --- |
| `sNOWFLAKE` |
| `aMAZONREDSHIFT` |
| `gOOGLEBIGQUERY` |
| `aZURESYNAPSE` |
| `tERADATA` |
| `sTARBURST` |
| `sAPHANA` |
| `oRACLEADW` |
| `dATABRICKS` |
| `dENODO` |
| `dREMIO` |

