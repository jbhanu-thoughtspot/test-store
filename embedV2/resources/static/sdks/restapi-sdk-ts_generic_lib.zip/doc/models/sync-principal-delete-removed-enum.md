
# Sync Principal Delete Removed Enum

Specifies whether to delete the users and groups already in the cluster if not present in the principal object list input.

## Enumeration

`SyncPrincipalDeleteRemovedEnum`

## Fields

| Name |
|  --- |
| `true` |
| `false` |

