
# Get Connection Tables Include Column Enum

When set to true, the response will include column level details as well.

## Enumeration

`GetConnectionTablesIncludeColumnEnum`

## Fields

| Name |
|  --- |
| `true` |
| `false` |

