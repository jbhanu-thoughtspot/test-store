
# Get Object Dependency Type Enum

Type of the data object

## Enumeration

`GetObjectDependencyTypeEnum`

## Fields

| Name |
|  --- |
| `lIVEBOARD` |
| `dATAOBJECT` |
| `cOLUMN` |
| `jOIN` |

