
# Search Connection Type Enum

Type of the connect being searched. Valid values:

## Enumeration

`SearchConnectionTypeEnum`

## Fields

| Name |
|  --- |
| `sNOWFLAKE` |
| `aMAZONREDSHIFT` |
| `gOOGLEBIGQUERY` |
| `aZURESYNAPSE` |
| `tERADATA` |
| `sTARBURST` |
| `sAPHANA` |
| `oRACLEADW` |
| `dATABRICKS` |
| `dENODO` |
| `dREMIO` |

