
# Logical Table Header Deleted Enum

## Enumeration

`LogicalTableHeaderDeletedEnum`

## Fields

| Name |
|  --- |
| `true` |
| `false` |

