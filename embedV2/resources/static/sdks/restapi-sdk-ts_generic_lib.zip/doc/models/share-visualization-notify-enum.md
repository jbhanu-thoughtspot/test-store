
# Share Visualization Notify Enum

When set to true, a notification is sent to the users after an object is shared.

## Enumeration

`ShareVisualizationNotifyEnum`

## Fields

| Name |
|  --- |
| `true` |
| `false` |

