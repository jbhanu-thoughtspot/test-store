
# Search Users State Enum

Status of user account. acitve or inactive.

## Enumeration

`SearchUsersStateEnum`

## Fields

| Name |
|  --- |
| `aCTIVE` |
| `iNACTIVE` |
| `eXPIRED` |
| `lOCKED` |
| `pENDING` |

