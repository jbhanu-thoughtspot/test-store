
# Sync Principal Update Modified Enum

Specifies whether to apply the changes to users and groups already in the cluster based on the principal object list input.

## Enumeration

`SyncPrincipalUpdateModifiedEnum`

## Fields

| Name |
|  --- |
| `true` |
| `false` |

