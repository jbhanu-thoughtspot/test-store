
# Table List Is External Enum

## Enumeration

`TableListIsExternalEnum`

## Fields

| Name |
|  --- |
| `true` |
| `false` |

