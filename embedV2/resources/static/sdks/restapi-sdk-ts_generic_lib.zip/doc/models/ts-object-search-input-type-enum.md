
# Ts Object Search Input Type Enum

Type of the metadata objec

## Enumeration

`TsObjectSearchInputTypeEnum`

## Fields

| Name |
|  --- |
| `lIVEBOARD` |
| `aNSWER` |
| `dATAOBJECT` |
| `cOLUMN` |

