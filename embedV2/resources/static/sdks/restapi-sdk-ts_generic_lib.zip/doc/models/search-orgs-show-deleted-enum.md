
# Search Orgs Show Deleted Enum

When set to true, the response will include the details of deleted organization also.

## Enumeration

`SearchOrgsShowDeletedEnum`

## Fields

| Name |
|  --- |
| `true` |
| `false` |

