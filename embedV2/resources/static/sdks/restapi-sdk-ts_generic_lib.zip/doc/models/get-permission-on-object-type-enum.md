
# Get Permission on Object Type Enum

## Enumeration

`GetPermissionOnObjectTypeEnum`

## Fields

| Name |
|  --- |
| `lIVEBOARD` |
| `aNSWER` |
| `dATAOBJECT` |
| `cOLUMN` |

