
# Update User State Enum

Status of user account. acitve or inactive.

## Enumeration

`UpdateUserStateEnum`

## Fields

| Name |
|  --- |
| `aCTIVE` |
| `iNACTIVE` |
| `eXPIRED` |
| `lOCKED` |
| `pENDING` |

