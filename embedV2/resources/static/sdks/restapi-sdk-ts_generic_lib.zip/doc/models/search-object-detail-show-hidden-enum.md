
# Search Object Detail Show Hidden Enum

When set to true, returns details of the hidden objects, such as a column in a worksheet or a table.

## Enumeration

`SearchObjectDetailShowHiddenEnum`

## Fields

| Name |
|  --- |
| `true` |
| `false` |

