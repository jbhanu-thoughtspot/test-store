
# Table Columns

## Structure

`TableColumns`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Optional | Name of the column |
| `dataType` | `string \| undefined` | Optional | Datatype of the column |

## Example (as JSON)

```json
{
  "name": null,
  "dataType": null
}
```

