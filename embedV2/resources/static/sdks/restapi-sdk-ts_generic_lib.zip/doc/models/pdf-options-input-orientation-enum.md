
# Pdf Options Input Orientation Enum

Page orientation for the PDF. Default: PORTRAIT

## Enumeration

`PdfOptionsInputOrientationEnum`

## Fields

| Name |
|  --- |
| `pORTRAIT` |
| `lANDSCAPE` |

