
# Logical Table Header Hidden Enum

## Enumeration

`LogicalTableHeaderHiddenEnum`

## Fields

| Name |
|  --- |
| `true` |
| `false` |

