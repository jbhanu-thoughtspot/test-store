
# Search Object Detail Type Enum

Type of the metadata object being searched. Valid values

## Enumeration

`SearchObjectDetailTypeEnum`

## Fields

| Name |
|  --- |
| `aNSWER` |
| `lIVEBOARD` |
| `dATAOBJECT` |
| `cOLUMN` |
| `jOIN` |
| `cONNECTION` |
| `tAG` |
| `uSER` |
| `uSERGROUP` |

