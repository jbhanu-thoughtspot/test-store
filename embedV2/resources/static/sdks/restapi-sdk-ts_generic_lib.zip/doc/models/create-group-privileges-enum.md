
# Create Group Privileges Enum

## Enumeration

`CreateGroupPrivilegesEnum`

## Fields

| Name |
|  --- |
| `aDMINISTRATION` |
| `aUTHORING` |
| `dEVELOPER` |
| `uSERDATAUPLOADING` |
| `dATADOWNLOADING` |
| `dATAMANAGEMENT` |
| `sHAREWITHALL` |
| `eXPERIMENTALFEATUREPRIVILEGE` |
| `jOBSCHEDULING` |
| `rANALYSIS` |
| `a3ANALYSIS` |
| `bYPASSRLS` |

