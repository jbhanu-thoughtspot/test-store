
# Get Object Header Type Enum

## Enumeration

`GetObjectHeaderTypeEnum`

## Fields

| Name |
|  --- |
| `aNSWER` |
| `lIVEBOARD` |
| `dATAOBJECTALL` |
| `dATAOBJECTWORKSHEET` |
| `dATAOBJECTTABLE` |
| `dATAOBJECTUSERDEFINED` |
| `dATAOBJECTVIEW` |
| `dATAOBJECTCALENDARTABLE` |
| `cOLUMNALL` |
| `cOLUMNWORKSHEET` |
| `cOLUMNTABLE` |
| `cOLUMNUSERDEFINED` |
| `cOLUMNVIEW` |
| `cOLUMNCALENDARTABLE` |
| `jOIN` |
| `cONNECTION` |
| `tAG` |
| `uSER` |
| `uSERGROUP` |

