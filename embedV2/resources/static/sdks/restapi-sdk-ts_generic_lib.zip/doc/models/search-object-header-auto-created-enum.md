
# Search Object Header Auto Created Enum

A flag to indicate whether to list only the auto created objects. When no value is provided as input then all objects are returned.

## Enumeration

`SearchObjectHeaderAutoCreatedEnum`

## Fields

| Name |
|  --- |
| `true` |
| `false` |

