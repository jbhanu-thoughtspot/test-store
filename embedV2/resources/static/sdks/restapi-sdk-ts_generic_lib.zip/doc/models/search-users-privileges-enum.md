
# Search Users Privileges Enum

## Enumeration

`SearchUsersPrivilegesEnum`

## Fields

| Name |
|  --- |
| `aDMINISTRATION` |
| `aUTHORING` |
| `dEVELOPER` |
| `uSERDATAUPLOADING` |
| `dATADOWNLOADING` |
| `dATAMANAGEMENT` |
| `sHAREWITHALL` |
| `eXPERIMENTALFEATUREPRIVILEGE` |
| `jOBSCHEDULING` |
| `rANALYSIS` |
| `a3ANALYSIS` |
| `bYPASSRLS` |

