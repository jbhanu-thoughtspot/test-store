
# Create User State Enum

Status of user account. acitve or inactive.

## Enumeration

`CreateUserStateEnum`

## Fields

| Name |
|  --- |
| `aCTIVE` |
| `iNACTIVE` |
| `eXPIRED` |
| `lOCKED` |
| `pENDING` |

