
# Create Connection Type Enum

Type of the data connection.

## Enumeration

`CreateConnectionTypeEnum`

## Fields

| Name |
|  --- |
| `sNOWFLAKE` |
| `aMAZONREDSHIFT` |
| `gOOGLEBIGQUERY` |
| `aZURESYNAPSE` |
| `tERADATA` |
| `sTARBURST` |
| `sAPHANA` |
| `oRACLEADW` |
| `dATABRICKS` |
| `dENODO` |
| `dREMIO` |

