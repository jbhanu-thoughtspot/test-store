
# Update User Show Walk Me Enum

The user preference for revisiting the onboarding experience.

## Enumeration

`UpdateUserShowWalkMeEnum`

## Fields

| Name |
|  --- |
| `true` |
| `false` |

