
# Share Object Type Enum

Type of metadata object

## Enumeration

`ShareObjectTypeEnum`

## Fields

| Name |
|  --- |
| `lIVEBOARD` |
| `aNSWER` |
| `dATAOBJECT` |
| `cOLUMN` |

