
# Get Object Detail Type Enum

## Enumeration

`GetObjectDetailTypeEnum`

## Fields

| Name |
|  --- |
| `aNSWER` |
| `lIVEBOARD` |
| `dATAOBJECT` |
| `cOLUMN` |
| `jOIN` |
| `cONNECTION` |
| `tAG` |
| `uSER` |
| `uSERGROUP` |

