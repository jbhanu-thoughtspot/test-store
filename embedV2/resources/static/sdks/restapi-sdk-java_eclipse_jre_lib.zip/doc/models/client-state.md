
# Client State

## Structure

`ClientState`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Color` | `String` | Optional | Color assigned to the tag | String getColor() | setColor(String color) |

## Example (as JSON)

```json
{
  "color": null
}
```

