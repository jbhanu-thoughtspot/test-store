
# Get Token Access Level Enum

User access privilege.

FULL - Creates a session with full access.

REPORT_BOOK_VIEW - Allow view access to the specified visualizations.

## Enumeration

`GetTokenAccessLevelEnum`

## Fields

| Name |
|  --- |
| `FULL` |
| `REPORTBOOKVIEW` |

