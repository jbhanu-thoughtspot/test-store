
# Export Object TML Format Type Enum

The format in which to export the objects

## Enumeration

`ExportObjectTMLFormatTypeEnum`

## Fields

| Name |
|  --- |
| `YAML` |
| `JSON` |

