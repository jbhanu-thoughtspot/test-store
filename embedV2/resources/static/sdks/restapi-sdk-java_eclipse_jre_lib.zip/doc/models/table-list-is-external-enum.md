
# Table List Is External Enum

## Enumeration

`TableListIsExternalEnum`

## Fields

| Name |
|  --- |
| `True` |
| `False` |

