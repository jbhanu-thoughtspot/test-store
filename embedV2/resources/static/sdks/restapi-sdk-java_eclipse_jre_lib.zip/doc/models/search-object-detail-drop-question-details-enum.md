
# Search Object Detail Drop Question Details Enum

When set to true, the search assist data associated with a worksheet is not included in the API response. This attribute is applicable only for DATAOBJECT data type.

## Enumeration

`SearchObjectDetailDropQuestionDetailsEnum`

## Fields

| Name |
|  --- |
| `True` |
| `False` |

