
# Update User State Enum

Status of user account. acitve or inactive.

## Enumeration

`UpdateUserStateEnum`

## Fields

| Name |
|  --- |
| `ACTIVE` |
| `INACTIVE` |
| `EXPIRED` |
| `LOCKED` |
| `PENDING` |

