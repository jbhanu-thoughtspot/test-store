
# Get Permission on Object Type Enum

## Enumeration

`GetPermissionOnObjectTypeEnum`

## Fields

| Name |
|  --- |
| `LIVEBOARD` |
| `ANSWER` |
| `DATAOBJECT` |
| `COLUMN` |

