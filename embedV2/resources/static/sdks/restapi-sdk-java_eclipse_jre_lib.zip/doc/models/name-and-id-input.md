
# Name and Id Input

## Structure

`NameAndIdInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | Name of the user | String getName() | setName(String name) |
| `Id` | `String` | Optional | GUID of the user | String getId() | setId(String id) |

## Example (as JSON)

```json
{
  "name": null,
  "id": null
}
```

