
# User Name and ID Input

## Structure

`UserNameAndIDInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | Username of the user | String getName() | setName(String name) |
| `Id` | `String` | Optional | GUID of the user | String getId() | setId(String id) |

## Example (as JSON)

```json
{
  "name": null,
  "id": null
}
```

