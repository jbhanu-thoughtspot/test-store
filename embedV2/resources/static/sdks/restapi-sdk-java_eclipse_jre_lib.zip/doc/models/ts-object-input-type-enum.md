
# Ts Object Input Type Enum

Type of the metadata object

## Enumeration

`TsObjectInputTypeEnum`

## Fields

| Name |
|  --- |
| `ANSWER` |
| `LIVEBOARD` |
| `DATAOBJECT` |
| `CONNECTION` |

