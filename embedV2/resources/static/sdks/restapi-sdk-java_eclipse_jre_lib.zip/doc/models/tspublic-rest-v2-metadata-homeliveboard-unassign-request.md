
# Tspublic Rest V2 Metadata Homeliveboard Unassign Request

## Structure

`TspublicRestV2MetadataHomeliveboardUnassignRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `UserName` | `String` | Optional | Name of the user | String getUserName() | setUserName(String userName) |
| `UserId` | `String` | Optional | The GUID of the user | String getUserId() | setUserId(String userId) |

## Example (as JSON)

```json
{
  "userName": null,
  "userId": null
}
```

