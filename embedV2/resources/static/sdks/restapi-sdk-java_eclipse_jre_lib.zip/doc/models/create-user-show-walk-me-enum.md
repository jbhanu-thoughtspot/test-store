
# Create User Show Walk Me Enum

The user preference for revisiting the onboarding experience.

## Enumeration

`CreateUserShowWalkMeEnum`

## Fields

| Name |
|  --- |
| `True` |
| `False` |

