
# Update User Notify on Share Enum

User preference for receiving email notifications when another ThoughtSpot user shares answers or pinboards.

## Enumeration

`UpdateUserNotifyOnShareEnum`

## Fields

| Name |
|  --- |
| `True` |
| `False` |

