
# Share Object Notify Enum

When set to true, a notification is sent to the users after an object is shared.

## Enumeration

`ShareObjectNotifyEnum`

## Fields

| Name |
|  --- |
| `True` |
| `False` |

