
# Table List Is Deprecated Enum

Indicates if the table is deprecated

## Enumeration

`TableListIsDeprecatedEnum`

## Fields

| Name |
|  --- |
| `True` |
| `False` |

