
# Search Connection Type Enum

Type of the connect being searched. Valid values:

## Enumeration

`SearchConnectionTypeEnum`

## Fields

| Name |
|  --- |
| `SNOWFLAKE` |
| `AMAZONREDSHIFT` |
| `GOOGLEBIGQUERY` |
| `AZURESYNAPSE` |
| `TERADATA` |
| `STARBURST` |
| `SAPHANA` |
| `ORACLEADW` |
| `DATABRICKS` |
| `DENODO` |
| `DREMIO` |

