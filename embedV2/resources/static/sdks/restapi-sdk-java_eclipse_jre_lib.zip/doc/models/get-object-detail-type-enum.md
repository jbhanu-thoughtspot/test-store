
# Get Object Detail Type Enum

## Enumeration

`GetObjectDetailTypeEnum`

## Fields

| Name |
|  --- |
| `ANSWER` |
| `LIVEBOARD` |
| `DATAOBJECT` |
| `COLUMN` |
| `JOIN` |
| `CONNECTION` |
| `TAG` |
| `USER` |
| `USERGROUP` |

