
# Get Object Header Type Enum

## Enumeration

`GetObjectHeaderTypeEnum`

## Fields

| Name |
|  --- |
| `ANSWER` |
| `LIVEBOARD` |
| `DATAOBJECTALL` |
| `DATAOBJECTWORKSHEET` |
| `DATAOBJECTTABLE` |
| `DATAOBJECTUSERDEFINED` |
| `DATAOBJECTVIEW` |
| `DATAOBJECTCALENDARTABLE` |
| `COLUMNALL` |
| `COLUMNWORKSHEET` |
| `COLUMNTABLE` |
| `COLUMNUSERDEFINED` |
| `COLUMNVIEW` |
| `COLUMNCALENDARTABLE` |
| `JOIN` |
| `CONNECTION` |
| `TAG` |
| `USER` |
| `USERGROUP` |

