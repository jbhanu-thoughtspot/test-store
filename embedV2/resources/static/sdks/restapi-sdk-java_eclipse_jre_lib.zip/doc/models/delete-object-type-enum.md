
# Delete Object Type Enum

## Enumeration

`DeleteObjectTypeEnum`

## Fields

| Name |
|  --- |
| `ANSWER` |
| `LIVEBOARD` |
| `DATAOBJECT` |
| `COLUMN` |
| `JOIN` |
| `CONNECTION` |
| `TAG` |
| `USER` |
| `USERGROUP` |

