
# Pdf Options Input Truncate Tables Enum

When set to true, only the first page of the tables is displayed in the file.

This setting is applicable only when generating report for specific visualization ids. Default: false

## Enumeration

`PdfOptionsInputTruncateTablesEnum`

## Fields

| Name |
|  --- |
| `True` |
| `False` |

