
# Table Columns

## Structure

`TableColumns`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Optional | Name of the column |
| `data_type` | `string` | Optional | Datatype of the column |

## Example (as JSON)

```json
{
  "name": null,
  "dataType": null
}
```

