
# Logical Table Header Hidden Enum

## Enumeration

`LogicalTableHeaderHiddenEnum`

## Fields

| Name |
|  --- |
| `TRUE` |
| `FALSE` |

