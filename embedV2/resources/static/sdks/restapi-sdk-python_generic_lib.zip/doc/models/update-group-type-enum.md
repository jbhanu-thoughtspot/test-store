
# Update Group Type Enum

Type of user group. LOCAL_GROUP indicates that the user is created locally in the ThoughtSpot system.

## Enumeration

`UpdateGroupTypeEnum`

## Fields

| Name |
|  --- |
| `LOCAL_GROUP` |
| `TENANT_GROUP` |

