
# Table Input

## Structure

`TableInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Optional | Name of the table |
| `id` | `string` | Optional | GUID of the Table |

## Example (as JSON)

```json
{
  "name": null,
  "id": null
}
```

