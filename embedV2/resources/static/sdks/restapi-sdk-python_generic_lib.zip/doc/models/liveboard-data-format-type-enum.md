
# Liveboard Data Format Type Enum

The format of the data in the response.

FULL: The response comes in "column":"value" format.

COMPACT: The response includes only the value of the columns.

## Enumeration

`LiveboardDataFormatTypeEnum`

## Fields

| Name |
|  --- |
| `COMPACT` |
| `FULL` |

