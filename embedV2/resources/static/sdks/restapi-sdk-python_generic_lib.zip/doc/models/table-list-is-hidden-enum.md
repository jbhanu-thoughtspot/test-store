
# Table List Is Hidden Enum

Indicates if the table is hideen

## Enumeration

`TableListIsHiddenEnum`

## Fields

| Name |
|  --- |
| `TRUE` |
| `FALSE` |

