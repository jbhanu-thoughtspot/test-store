
# Pdf Options Input Include Logo Enum

Include customized wide logo if available in the footer. Default: true

## Enumeration

`PdfOptionsInputIncludeLogoEnum`

## Fields

| Name |
|  --- |
| `TRUE` |
| `FALSE` |

