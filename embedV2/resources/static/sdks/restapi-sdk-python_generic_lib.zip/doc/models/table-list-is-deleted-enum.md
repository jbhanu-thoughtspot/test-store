
# Table List Is Deleted Enum

Indicates if the table is deleted

## Enumeration

`TableListIsDeletedEnum`

## Fields

| Name |
|  --- |
| `TRUE` |
| `FALSE` |

