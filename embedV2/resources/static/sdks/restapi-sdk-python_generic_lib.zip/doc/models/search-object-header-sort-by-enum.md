
# Search Object Header Sort by Enum

Field based on which the response needs to be ordered.

## Enumeration

`SearchObjectHeaderSortByEnum`

## Fields

| Name |
|  --- |
| `DEFAULT` |
| `NAME` |
| `DISPLAY_NAME` |
| `AUTHOR` |
| `CREATED` |
| `MODIFIED` |
| `LAST_ACCESSED` |
| `SYNCED` |
| `VIEWS` |
| `NONE` |
| `USER_STATE` |
| `ROW_COUNT` |

