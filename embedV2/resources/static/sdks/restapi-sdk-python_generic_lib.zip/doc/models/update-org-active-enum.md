
# Update Org Active Enum

Status of the organization.

## Enumeration

`UpdateOrgActiveEnum`

## Fields

| Name |
|  --- |
| `TRUE` |
| `FALSE` |

