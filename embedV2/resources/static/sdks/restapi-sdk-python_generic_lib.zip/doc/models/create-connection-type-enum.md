
# Create Connection Type Enum

Type of the data connection.

## Enumeration

`CreateConnectionTypeEnum`

## Fields

| Name |
|  --- |
| `SNOWFLAKE` |
| `AMAZON_REDSHIFT` |
| `GOOGLE_BIGQUERY` |
| `AZURE_SYNAPSE` |
| `TERADATA` |
| `STARBURST` |
| `SAP_HANA` |
| `ORACLE_ADW` |
| `DATABRICKS` |
| `DENODO` |
| `DREMIO` |

