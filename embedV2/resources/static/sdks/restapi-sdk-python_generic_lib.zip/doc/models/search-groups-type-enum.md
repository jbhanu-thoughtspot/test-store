
# Search Groups Type Enum

Type of user group. LOCAL_GROUP indicates that the user is created locally in the ThoughtSpot system.

## Enumeration

`SearchGroupsTypeEnum`

## Fields

| Name |
|  --- |
| `LOCAL_GROUP` |
| `TENANT_GROUP` |

