
# Create Table Create Database Enum

Flag to indicate if the database and schema should be created if they do not exist in Falcon. (Valid values: True/False)

## Enumeration

`CreateTableCreateDatabaseEnum`

## Fields

| Name |
|  --- |
| `TRUE` |
| `FALSE` |

