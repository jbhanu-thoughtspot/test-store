
# Search Connection Type Enum

Type of the connect being searched. Valid values:

## Enumeration

`SearchConnectionTypeEnum`

## Fields

| Name |
|  --- |
| `SNOWFLAKE` |
| `AMAZON_REDSHIFT` |
| `GOOGLE_BIGQUERY` |
| `AZURE_SYNAPSE` |
| `TERADATA` |
| `STARBURST` |
| `SAP_HANA` |
| `ORACLE_ADW` |
| `DATABRICKS` |
| `DENODO` |
| `DREMIO` |

