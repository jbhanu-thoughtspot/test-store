
# Share Object Include Custom Embed Url Enum

When set to true, ThoughtSpot sends a link with the host application context to allow users to access the shared object from their ThoughtSpot embedded instance.

## Enumeration

`ShareObjectIncludeCustomEmbedUrlEnum`

## Fields

| Name |
|  --- |
| `TRUE` |
| `FALSE` |

