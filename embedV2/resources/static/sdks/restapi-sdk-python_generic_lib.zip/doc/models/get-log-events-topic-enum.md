
# Get Log Events Topic Enum

## Enumeration

`GetLogEventsTopicEnum`

## Fields

| Name |
|  --- |
| `SECURITY_LOGS` |

