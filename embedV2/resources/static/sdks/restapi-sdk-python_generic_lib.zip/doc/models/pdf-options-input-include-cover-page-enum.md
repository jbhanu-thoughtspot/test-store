
# Pdf Options Input Include Cover Page Enum

When set to true, a cover page with the Liveboard title is added in the PDF. Default: true

## Enumeration

`PdfOptionsInputIncludeCoverPageEnum`

## Fields

| Name |
|  --- |
| `TRUE` |
| `FALSE` |

