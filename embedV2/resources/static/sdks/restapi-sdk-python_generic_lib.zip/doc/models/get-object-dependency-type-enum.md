
# Get Object Dependency Type Enum

Type of the data object

## Enumeration

`GetObjectDependencyTypeEnum`

## Fields

| Name |
|  --- |
| `LIVEBOARD` |
| `DATAOBJECT` |
| `COLUMN` |
| `JOIN` |

