
# Pdf Options Input Include Page Number Enum

When set to true, the page number is included in the footer of each page. Default: true

## Enumeration

`PdfOptionsInputIncludePageNumberEnum`

## Fields

| Name |
|  --- |
| `TRUE` |
| `FALSE` |

