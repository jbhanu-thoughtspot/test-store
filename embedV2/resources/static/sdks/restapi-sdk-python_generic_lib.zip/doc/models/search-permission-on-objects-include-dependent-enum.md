
# Search Permission on Objects Include Dependent Enum

When this field is set to true, the API response includes the permission details for the dependent objects

## Enumeration

`SearchPermissionOnObjectsIncludeDependentEnum`

## Fields

| Name |
|  --- |
| `TRUE` |
| `FALSE` |

