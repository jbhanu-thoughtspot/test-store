
# Access Level Input Type Enum

Type of access detail provided

## Enumeration

`AccessLevelInputTypeEnum`

## Fields

| Name |
|  --- |
| `USER` |
| `USER_GROUP` |

