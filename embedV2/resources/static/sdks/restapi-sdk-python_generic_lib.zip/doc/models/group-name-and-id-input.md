
# Group Name and ID Input

## Structure

`GroupNameAndIDInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Optional | Name of the group |
| `id` | `string` | Optional | GUID of the group |

## Example (as JSON)

```json
{
  "name": null,
  "id": null
}
```

