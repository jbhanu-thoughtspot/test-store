
# Get Object Header Type Enum

## Enumeration

`GetObjectHeaderTypeEnum`

## Fields

| Name |
|  --- |
| `ANSWER` |
| `LIVEBOARD` |
| `DATAOBJECT_ALL` |
| `DATAOBJECT_WORKSHEET` |
| `DATAOBJECT_TABLE` |
| `DATAOBJECT_USER_DEFINED` |
| `DATAOBJECT_VIEW` |
| `DATAOBJECT_CALENDAR_TABLE` |
| `COLUMN_ALL` |
| `COLUMN_WORKSHEET` |
| `COLUMN_TABLE` |
| `COLUMN_USER_DEFINED` |
| `COLUMN_VIEW` |
| `COLUMN_CALENDAR_TABLE` |
| `JOIN` |
| `CONNECTION` |
| `TAG` |
| `USER` |
| `USER_GROUP` |

