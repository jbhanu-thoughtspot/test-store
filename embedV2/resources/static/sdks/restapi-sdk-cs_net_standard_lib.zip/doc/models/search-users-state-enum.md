
# Search Users State Enum

Status of user account. acitve or inactive.

## Enumeration

`SearchUsersStateEnum`

## Fields

| Name |
|  --- |
| `ACTIVE` |
| `INACTIVE` |
| `EXPIRED` |
| `LOCKED` |
| `PENDING` |

