
# Search Users Privileges Enum

## Enumeration

`SearchUsersPrivilegesEnum`

## Fields

| Name |
|  --- |
| `ADMINISTRATION` |
| `AUTHORING` |
| `DEVELOPER` |
| `USERDATAUPLOADING` |
| `DATADOWNLOADING` |
| `DATAMANAGEMENT` |
| `SHAREWITHALL` |
| `EXPERIMENTALFEATUREPRIVILEGE` |
| `JOBSCHEDULING` |
| `RANALYSIS` |
| `A3ANALYSIS` |
| `BYPASSRLS` |

