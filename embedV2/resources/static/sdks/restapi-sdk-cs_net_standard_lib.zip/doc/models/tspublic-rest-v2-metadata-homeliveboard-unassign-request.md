
# Tspublic Rest V2 Metadata Homeliveboard Unassign Request

## Structure

`TspublicRestV2MetadataHomeliveboardUnassignRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `UserName` | `string` | Optional | Name of the user |
| `UserId` | `string` | Optional | The GUID of the user |

## Example (as JSON)

```json
{
  "userName": null,
  "userId": null
}
```

