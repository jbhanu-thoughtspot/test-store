
# Get Log Events Topic Enum

## Enumeration

`GetLogEventsTopicEnum`

## Fields

| Name |
|  --- |
| `SecurityLogs` |

