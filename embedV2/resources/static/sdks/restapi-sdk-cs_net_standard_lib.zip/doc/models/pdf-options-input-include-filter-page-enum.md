
# Pdf Options Input Include Filter Page Enum

When set to true, a second page with a list of all applied filters is added in the PDF. Default: true

## Enumeration

`PdfOptionsInputIncludeFilterPageEnum`

## Fields

| Name |
|  --- |
| `True` |
| `False` |

