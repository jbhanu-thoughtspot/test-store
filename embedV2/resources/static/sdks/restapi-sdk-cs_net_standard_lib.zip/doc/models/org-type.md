
# Org Type

## Structure

`OrgType`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | Name of the organization |
| `Id` | `int?` | Optional | Id of the organization |

## Example (as JSON)

```json
{
  "name": null,
  "id": null
}
```

