
# Ts Object Search Input Type Enum

Type of the metadata objec

## Enumeration

`TsObjectSearchInputTypeEnum`

## Fields

| Name |
|  --- |
| `LIVEBOARD` |
| `ANSWER` |
| `DATAOBJECT` |
| `COLUMN` |

