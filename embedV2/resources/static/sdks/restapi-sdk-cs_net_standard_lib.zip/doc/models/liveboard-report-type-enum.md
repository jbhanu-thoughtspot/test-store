
# Liveboard Report Type Enum

Type of file to be generated.

## Enumeration

`LiveboardReportTypeEnum`

## Fields

| Name |
|  --- |
| `CSV` |
| `XLSX` |
| `PDF` |
| `PNG` |

