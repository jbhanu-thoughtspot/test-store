
# Search Connection Sort by Enum

Field based on which the response needs to be ordered.

## Enumeration

`SearchConnectionSortByEnum`

## Fields

| Name |
|  --- |
| `DEFAULT` |
| `NAME` |
| `DISPLAYNAME` |
| `AUTHOR` |
| `CREATED` |
| `MODIFIED` |
| `LASTACCESSED` |
| `SYNCED` |
| `VIEWS` |
| `NONE` |
| `USERSTATE` |
| `ROWCOUNT` |

