
# Columns Input

## Structure

`ColumnsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | Name of the column |
| `DataType` | `string` | Required | Datatype of the column |

## Example (as JSON)

```json
{
  "name": "name0",
  "dataType": "dataType2"
}
```

