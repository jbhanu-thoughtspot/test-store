
# Liveboard Name and ID

## Structure

`LiveboardNameAndID`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | Name of the liveboard |
| `Id` | `string` | Optional | GUID of the liveboard |

## Example (as JSON)

```json
{
  "name": null,
  "id": null
}
```

