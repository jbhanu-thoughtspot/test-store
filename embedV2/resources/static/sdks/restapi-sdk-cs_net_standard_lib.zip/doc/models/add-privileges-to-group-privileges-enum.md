
# Add Privileges to Group Privileges Enum

## Enumeration

`AddPrivilegesToGroupPrivilegesEnum`

## Fields

| Name |
|  --- |
| `ADMINISTRATION` |
| `AUTHORING` |
| `DEVELOPER` |
| `USERDATAUPLOADING` |
| `DATADOWNLOADING` |
| `DATAMANAGEMENT` |
| `SHAREWITHALL` |
| `EXPERIMENTALFEATUREPRIVILEGE` |
| `JOBSCHEDULING` |
| `RANALYSIS` |
| `A3ANALYSIS` |
| `BYPASSRLS` |

