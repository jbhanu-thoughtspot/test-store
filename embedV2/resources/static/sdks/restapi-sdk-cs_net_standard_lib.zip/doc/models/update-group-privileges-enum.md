
# Update Group Privileges Enum

## Enumeration

`UpdateGroupPrivilegesEnum`

## Fields

| Name |
|  --- |
| `ADMINISTRATION` |
| `AUTHORING` |
| `DEVELOPER` |
| `USERDATAUPLOADING` |
| `DATADOWNLOADING` |
| `DATAMANAGEMENT` |
| `SHAREWITHALL` |
| `EXPERIMENTALFEATUREPRIVILEGE` |
| `JOBSCHEDULING` |
| `RANALYSIS` |
| `A3ANALYSIS` |
| `BYPASSRLS` |

