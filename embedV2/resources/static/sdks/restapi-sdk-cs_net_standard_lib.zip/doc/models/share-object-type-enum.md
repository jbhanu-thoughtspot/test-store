
# Share Object Type Enum

Type of metadata object

## Enumeration

`ShareObjectTypeEnum`

## Fields

| Name |
|  --- |
| `LIVEBOARD` |
| `ANSWER` |
| `DATAOBJECT` |
| `COLUMN` |

