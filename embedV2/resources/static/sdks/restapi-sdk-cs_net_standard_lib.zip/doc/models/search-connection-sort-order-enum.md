
# Search Connection Sort Order Enum

Order in which sortBy should be applied.

## Enumeration

`SearchConnectionSortOrderEnum`

## Fields

| Name |
|  --- |
| `DEFAULT` |
| `ASC` |
| `DESC` |

