
# Client State

## Structure

`ClientState`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Color` | `string` | Optional | Color assigned to the tag |

## Example (as JSON)

```json
{
  "color": null
}
```

