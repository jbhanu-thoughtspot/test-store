
# Create Group Privileges Enum

## Enumeration

`CreateGroupPrivilegesEnum`

## Fields

| Name |
|  --- |
| `ADMINISTRATION` |
| `AUTHORING` |
| `DEVELOPER` |
| `USERDATAUPLOADING` |
| `DATADOWNLOADING` |
| `DATAMANAGEMENT` |
| `SHAREWITHALL` |
| `EXPERIMENTALFEATUREPRIVILEGE` |
| `JOBSCHEDULING` |
| `RANALYSIS` |
| `A3ANALYSIS` |
| `BYPASSRLS` |

