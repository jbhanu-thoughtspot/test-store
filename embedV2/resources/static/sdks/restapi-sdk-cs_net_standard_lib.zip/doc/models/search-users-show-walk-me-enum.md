
# Search Users Show Walk Me Enum

The user preference for revisiting the onboarding experience.

## Enumeration

`SearchUsersShowWalkMeEnum`

## Fields

| Name |
|  --- |
| `True` |
| `False` |

