
# Remove Privileges From Group Privileges Enum

## Enumeration

`RemovePrivilegesFromGroupPrivilegesEnum`

## Fields

| Name |
|  --- |
| `ADMINISTRATION` |
| `AUTHORING` |
| `DEVELOPER` |
| `USERDATAUPLOADING` |
| `DATADOWNLOADING` |
| `DATAMANAGEMENT` |
| `SHAREWITHALL` |
| `EXPERIMENTALFEATUREPRIVILEGE` |
| `JOBSCHEDULING` |
| `RANALYSIS` |
| `A3ANALYSIS` |
| `BYPASSRLS` |

