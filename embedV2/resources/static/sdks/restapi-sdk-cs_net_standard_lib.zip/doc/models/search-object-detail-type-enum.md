
# Search Object Detail Type Enum

Type of the metadata object being searched. Valid values

## Enumeration

`SearchObjectDetailTypeEnum`

## Fields

| Name |
|  --- |
| `ANSWER` |
| `LIVEBOARD` |
| `DATAOBJECT` |
| `COLUMN` |
| `JOIN` |
| `CONNECTION` |
| `TAG` |
| `USER` |
| `USERGROUP` |

