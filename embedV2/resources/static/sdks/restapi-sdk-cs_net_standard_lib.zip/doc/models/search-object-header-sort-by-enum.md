
# Search Object Header Sort by Enum

Field based on which the response needs to be ordered.

## Enumeration

`SearchObjectHeaderSortByEnum`

## Fields

| Name |
|  --- |
| `DEFAULT` |
| `NAME` |
| `DISPLAYNAME` |
| `AUTHOR` |
| `CREATED` |
| `MODIFIED` |
| `LASTACCESSED` |
| `SYNCED` |
| `VIEWS` |
| `NONE` |
| `USERSTATE` |
| `ROWCOUNT` |

