
# Logical Table Header Hidden Enum

## Enumeration

`LogicalTableHeaderHiddenEnum`

## Fields

| Name |
|  --- |
| `True` |
| `False` |

