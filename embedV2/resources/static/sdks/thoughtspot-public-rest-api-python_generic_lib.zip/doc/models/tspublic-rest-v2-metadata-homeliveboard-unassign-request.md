
# Tspublic Rest V2 Metadata Homeliveboard Unassign Request

## Structure

`TspublicRestV2MetadataHomeliveboardUnassignRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_name` | `string` | Optional | Name of the user |
| `user_id` | `string` | Optional | The GUID of the user |

## Example (as JSON)

```json
{
  "userName": null,
  "userId": null
}
```

