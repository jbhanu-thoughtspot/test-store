
# Tspublic Rest V2 Materialization Refreshview Request

## Structure

`TspublicRestV2MaterializationRefreshviewRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Required | GUID of metadata object |

## Example (as JSON)

```json
{
  "id": "id0"
}
```

