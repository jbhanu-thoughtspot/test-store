
# Error Response Exception

## Structure

`ErrorResponseException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | `object` | Optional | - |

## Example (as JSON)

```json
{
  "error": null
}
```

