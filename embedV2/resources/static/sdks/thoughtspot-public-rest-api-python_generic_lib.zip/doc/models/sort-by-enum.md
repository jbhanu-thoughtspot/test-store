
# Sort by Enum

Field based on which the response needs to be ordered.

## Enumeration

`SortByEnum`

## Fields

| Name |
|  --- |
| `DEFAULT` |
| `NAME` |
| `DISPLAY_NAME` |
| `AUTHOR` |
| `CREATED` |
| `MODIFIED` |
| `LAST_ACCESSED` |
| `SYNCED` |
| `VIEWS` |
| `NONE` |
| `USER_STATE` |
| `ROW_COUNT` |

