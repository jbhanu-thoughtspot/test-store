
# Type 7 Enum

## Enumeration

`Type7Enum`

## Fields

| Name |
|  --- |
| `LIVEBOARD` |
| `ANSWER` |
| `DATAOBJECT` |
| `COLUMN` |

