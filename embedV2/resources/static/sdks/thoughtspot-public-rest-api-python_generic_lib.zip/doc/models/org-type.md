
# Org Type

## Structure

`OrgType`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Optional | Name of the organization |
| `id` | `int` | Optional | Id of the organization |

## Example (as JSON)

```json
{
  "name": null,
  "id": null
}
```

