
# Sort by 1 Enum

Field based on which the re.sponse needs to be ordered. Valid values

## Enumeration

`SortBy1Enum`

## Fields

| Name |
|  --- |
| `DEFAULT` |
| `NAME` |
| `DISPLAY_NAME` |
| `AUTHOR` |
| `CREATED` |
| `MODIFIED` |
| `LAST_ACCESSED` |
| `SYNCED` |
| `VIEWS` |
| `NONE` |
| `USER_STATE` |
| `ROW_COUNT` |

