
# Import Policy Enum

Policy to follow during import

## Enumeration

`ImportPolicyEnum`

## Fields

| Name |
|  --- |
| `PARTIAL` |
| `ALL_OR_NONE` |
| `VALIDATE_ONLY` |

