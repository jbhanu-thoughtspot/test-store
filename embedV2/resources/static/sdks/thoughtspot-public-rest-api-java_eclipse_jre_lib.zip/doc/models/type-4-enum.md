
# Type 4 Enum

## Enumeration

`Type4Enum`

## Fields

| Name |
|  --- |
| `ANSWER` |
| `LIVEBOARD` |
| `DATAOBJECT` |
| `COLUMN` |
| `JOIN` |
| `CONNECTION` |
| `TAG` |
| `USER` |
| `USERGROUP` |

