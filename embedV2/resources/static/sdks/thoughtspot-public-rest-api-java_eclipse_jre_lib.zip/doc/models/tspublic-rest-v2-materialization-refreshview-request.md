
# Tspublic Rest V2 Materialization Refreshview Request

## Structure

`TspublicRestV2MaterializationRefreshviewRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Required | GUID of metadata object | String getId() | setId(String id) |

## Example (as JSON)

```json
{
  "id": "id0"
}
```

