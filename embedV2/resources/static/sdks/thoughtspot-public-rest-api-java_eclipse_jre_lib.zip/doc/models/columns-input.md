
# Columns Input

## Structure

`ColumnsInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Required | Name of the column | String getName() | setName(String name) |
| `DataType` | `String` | Required | Datatype of the column | String getDataType() | setDataType(String dataType) |

## Example (as JSON)

```json
{
  "name": "name0",
  "dataType": "dataType2"
}
```

