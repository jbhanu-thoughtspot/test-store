
# Org Type

## Structure

`OrgType`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | Name of the organization | String getName() | setName(String name) |
| `Id` | `Integer` | Optional | Id of the organization | Integer getId() | setId(Integer id) |

## Example (as JSON)

```json
{
  "name": null,
  "id": null
}
```

