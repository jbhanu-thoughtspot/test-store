
# Tag Name and Id Input

## Structure

`TagNameAndIdInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | Name of the tags | String getName() | setName(String name) |
| `Id` | `String` | Optional | GUID of the tags | String getId() | setId(String id) |

## Example (as JSON)

```json
{
  "name": null,
  "id": null
}
```

