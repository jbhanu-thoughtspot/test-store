
# Orientation Enum

Page orientation for the PDF. Default: PORTRAIT

## Enumeration

`OrientationEnum`

## Fields

| Name |
|  --- |
| `PORTRAIT` |
| `LANDSCAPE` |

