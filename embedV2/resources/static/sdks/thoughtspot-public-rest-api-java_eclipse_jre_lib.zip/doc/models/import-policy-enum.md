
# Import Policy Enum

Policy to follow during import

## Enumeration

`ImportPolicyEnum`

## Fields

| Name |
|  --- |
| `PARTIAL` |
| `ALLORNONE` |
| `VALIDATEONLY` |

