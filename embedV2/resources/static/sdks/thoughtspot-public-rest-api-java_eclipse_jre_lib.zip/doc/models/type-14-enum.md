
# Type 14 Enum

Type of the data connection.

## Enumeration

`Type14Enum`

## Fields

| Name |
|  --- |
| `SNOWFLAKE` |
| `AMAZONREDSHIFT` |
| `GOOGLEBIGQUERY` |
| `AZURESYNAPSE` |
| `TERADATA` |
| `STARBURST` |
| `SAPHANA` |
| `ORACLEADW` |
| `DATABRICKS` |
| `DENODO` |
| `DREMIO` |

