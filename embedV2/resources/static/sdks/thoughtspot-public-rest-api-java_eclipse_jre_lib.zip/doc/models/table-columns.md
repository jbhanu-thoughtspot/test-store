
# Table Columns

## Structure

`TableColumns`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | Name of the column | String getName() | setName(String name) |
| `DataType` | `String` | Optional | Datatype of the column | String getDataType() | setDataType(String dataType) |

## Example (as JSON)

```json
{
  "name": null,
  "dataType": null
}
```

