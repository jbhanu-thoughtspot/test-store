
# Error Response Exception

## Structure

`ErrorResponseException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Error` | `Object` | Optional | - | Object getError() | setError(Object error) |

## Example (as JSON)

```json
{
  "error": null
}
```

