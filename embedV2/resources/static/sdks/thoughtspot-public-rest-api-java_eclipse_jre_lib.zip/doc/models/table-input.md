
# Table Input

## Structure

`TableInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | Name of the table | String getName() | setName(String name) |
| `Id` | `String` | Optional | GUID of the Table | String getId() | setId(String id) |

## Example (as JSON)

```json
{
  "name": null,
  "id": null
}
```

