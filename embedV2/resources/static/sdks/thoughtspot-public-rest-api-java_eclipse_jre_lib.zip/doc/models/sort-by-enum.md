
# Sort by Enum

Field based on which the response needs to be ordered.

## Enumeration

`SortByEnum`

## Fields

| Name |
|  --- |
| `DEFAULT` |
| `NAME` |
| `DISPLAYNAME` |
| `AUTHOR` |
| `CREATED` |
| `MODIFIED` |
| `LASTACCESSED` |
| `SYNCED` |
| `VIEWS` |
| `NONE` |
| `USERSTATE` |
| `ROWCOUNT` |

