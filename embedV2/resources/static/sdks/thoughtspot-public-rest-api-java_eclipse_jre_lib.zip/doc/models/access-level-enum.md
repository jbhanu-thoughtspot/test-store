
# Access Level Enum

User access privilege.

FULL - Creates a session with full access.

REPORT_BOOK_VIEW - Allow view access to the specified visualizations.

## Enumeration

`AccessLevelEnum`

## Fields

| Name |
|  --- |
| `FULL` |
| `REPORTBOOKVIEW` |

